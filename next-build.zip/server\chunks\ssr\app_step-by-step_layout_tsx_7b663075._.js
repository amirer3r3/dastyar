module.exports=[9070,a=>{"use strict";var b=a.i(7997);function c({children:a}){return(0,b.jsx)("div",{className:"step-by-step-section",children:a})}a.s(["default",()=>c])}];

//# sourceMappingURL=app_step-by-step_layout_tsx_7b663075._.js.map