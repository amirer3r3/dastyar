module.exports=[72784,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_worksheets_page_actions_99468846.js.map