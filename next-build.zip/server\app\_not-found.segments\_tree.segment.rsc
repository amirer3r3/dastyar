:HL["/_next/static/chunks/6e5804754cfd95a2.css","style"]
:HL["/_next/static/chunks/2aa95e1a4145414d.css","style"]
0:{"buildId":"LlRqgJeuTyn1HWTcxXUPp","tree":{"name":"","paramType":null,"paramKey":"","hasRuntimePrefetch":false,"slots":{"children":{"name":"/_not-found","paramType":null,"paramKey":"/_not-found","hasRuntimePrefetch":false,"slots":{"children":{"name":"__PAGE__","paramType":null,"paramKey":"__PAGE__","hasRuntimePrefetch":false,"slots":null,"isRootLayout":false}},"isRootLayout":false}},"isRootLayout":true},"staleTime":300}
