module.exports=[20292,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_marketplace_download_%5Bid%5D_route_actions_9eb4d48a.js.map