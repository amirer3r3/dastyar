module.exports=[38120,a=>{"use strict";var b=a.i(7997);function c({children:a}){return(0,b.jsx)("div",{className:"lesson-plan-section",children:a})}a.s(["default",()=>c])}];

//# sourceMappingURL=app_lesson-plan_layout_tsx_c9fa37ed._.js.map