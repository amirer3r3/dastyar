var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/marketplace/download/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__0949fed3._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_26499851._.js")
R.c("server/chunks/_next-internal_server_app_api_marketplace_download_[id]_route_actions_9eb4d48a.js")
R.m(8339)
module.exports=R.m(8339).exports
