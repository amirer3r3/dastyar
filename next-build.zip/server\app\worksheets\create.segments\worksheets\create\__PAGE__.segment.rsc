1:"$Sreact.fragment"
2:"$Sreact.suspense"
3:I[69515,["/_next/static/chunks/1bce1ea1a2f80acd.js","/_next/static/chunks/1648de61085f6622.js","/_next/static/chunks/b5a2e1a3733ee517.js"],"default"]
4:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/d2be314c3ece3fbe.js"],"OutletBoundary"]
:HL["/_next/static/chunks/23c0fd5017a2b615.css","style"]
0:{"buildId":"LlRqgJeuTyn1HWTcxXUPp","rsc":["$","$1","c",{"children":[["$","$2",null,{"fallback":["$","div",null,{"className":"p-6 text-center text-sm text-muted","children":"در حال بارگذاری…"}],"children":["$","$L3",null,{}]}],[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/23c0fd5017a2b615.css","precedence":"next"}],["$","script","script-0",{"src":"/_next/static/chunks/1648de61085f6622.js","async":true}],["$","script","script-1",{"src":"/_next/static/chunks/b5a2e1a3733ee517.js","async":true}]],["$","$L4",null,{"children":["$","$2",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"loading":null,"isPartial":false}
5:null
