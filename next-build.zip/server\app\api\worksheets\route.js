var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/worksheets/route.js")
R.c("server/chunks/[root-of-the-server]__cba739d5._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_worksheets_route_actions_82f755d5.js")
R.m(55242)
module.exports=R.m(55242).exports
