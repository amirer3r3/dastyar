module.exports=[87351,(e,o,d)=>{}];

//# sourceMappingURL=ce889_server_app_api_marketplace_cover_%5Bfilename%5D_route_actions_e7ce800f.js.map