module.exports=[7481,a=>{"use strict";var b=a.i(7997);function c({children:a}){return(0,b.jsx)("div",{className:"sample-question-section",children:a})}a.s(["default",()=>c])}];

//# sourceMappingURL=app_question-bank_layout_tsx_40e013a2._.js.map