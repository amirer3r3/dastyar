var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/marketplace/cover/[filename]/route.js")
R.c("server/chunks/[root-of-the-server]__d1663929._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/ce889_server_app_api_marketplace_cover_[filename]_route_actions_e7ce800f.js")
R.m(55326)
module.exports=R.m(55326).exports
